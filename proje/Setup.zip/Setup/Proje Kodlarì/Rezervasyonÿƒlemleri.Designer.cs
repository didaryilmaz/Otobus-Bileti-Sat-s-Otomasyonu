﻿namespace OBS_Proje
{
    partial class Rezervasyonİşlemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rezervasyonİşlemleri));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.seferİslemTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oBS_ProjeDataSet1 = new OBS_Proje.OBS_ProjeDataSet1();
            this.label11 = new System.Windows.Forms.Label();
            this.btnGeriDön = new System.Windows.Forms.Button();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.seferİslemTblTableAdapter = new OBS_Proje.OBS_ProjeDataSet1TableAdapters.SeferİslemTblTableAdapter();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxMüsAdı = new System.Windows.Forms.TextBox();
            this.textBoxMüsSoy = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.maskedTextBoxTel = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxCinsiyet = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxTc = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.btnDeğiştir = new System.Windows.Forms.Button();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.lblGizli = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.neredenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nereyeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferSaatiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otobüsAdıDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.peronNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferÜcretiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.koltukNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferİslemTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.oBS_ProjeDataSet5 = new OBS_Proje.OBS_ProjeDataSet5();
            this.seferİslemTblTableAdapter1 = new OBS_Proje.OBS_ProjeDataSet5TableAdapters.SeferİslemTblTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seferİslemTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seferİslemTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet5)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-20, -5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1310, 778);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // seferİslemTblBindingSource
            // 
            this.seferİslemTblBindingSource.DataMember = "SeferİslemTbl";
            this.seferİslemTblBindingSource.DataSource = this.oBS_ProjeDataSet1;
            // 
            // oBS_ProjeDataSet1
            // 
            this.oBS_ProjeDataSet1.DataSetName = "OBS_ProjeDataSet1";
            this.oBS_ProjeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label11.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(26, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(341, 23);
            this.label11.TabIndex = 8;
            this.label11.Text = "Sefer seçimini buradan yapınız...";
            // 
            // btnGeriDön
            // 
            this.btnGeriDön.BackColor = System.Drawing.Color.Maroon;
            this.btnGeriDön.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeriDön.ForeColor = System.Drawing.Color.White;
            this.btnGeriDön.Image = ((System.Drawing.Image)(resources.GetObject("btnGeriDön.Image")));
            this.btnGeriDön.Location = new System.Drawing.Point(957, 6);
            this.btnGeriDön.Name = "btnGeriDön";
            this.btnGeriDön.Size = new System.Drawing.Size(294, 43);
            this.btnGeriDön.TabIndex = 14;
            this.btnGeriDön.Text = "Yönetici Sayfasına Dön";
            this.btnGeriDön.UseVisualStyleBackColor = false;
            this.btnGeriDön.Click += new System.EventHandler(this.btnGeriDön_Click);
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDevamEt.ForeColor = System.Drawing.Color.Red;
            this.btnDevamEt.Image = ((System.Drawing.Image)(resources.GetObject("btnDevamEt.Image")));
            this.btnDevamEt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDevamEt.Location = new System.Drawing.Point(389, 647);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(507, 50);
            this.btnDevamEt.TabIndex = 15;
            this.btnDevamEt.Text = "Rezervasyon Yap";
            this.btnDevamEt.UseVisualStyleBackColor = true;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // seferİslemTblTableAdapter
            // 
            this.seferİslemTblTableAdapter.ClearBeforeFill = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(165, 43);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "Adı :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(135, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 24);
            this.label14.TabIndex = 4;
            this.label14.Text = "Soyadı :";
            // 
            // textBoxMüsAdı
            // 
            this.textBoxMüsAdı.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxMüsAdı.Location = new System.Drawing.Point(230, 40);
            this.textBoxMüsAdı.Name = "textBoxMüsAdı";
            this.textBoxMüsAdı.Size = new System.Drawing.Size(215, 30);
            this.textBoxMüsAdı.TabIndex = 6;
            // 
            // textBoxMüsSoy
            // 
            this.textBoxMüsSoy.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxMüsSoy.Location = new System.Drawing.Point(230, 91);
            this.textBoxMüsSoy.Name = "textBoxMüsSoy";
            this.textBoxMüsSoy.Size = new System.Drawing.Size(215, 30);
            this.textBoxMüsSoy.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(100, 196);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 24);
            this.label10.TabIndex = 21;
            this.label10.Text = "Telefon No :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(125, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 24);
            this.label9.TabIndex = 23;
            this.label9.Text = "Cinsiyet :";
            // 
            // maskedTextBoxTel
            // 
            this.maskedTextBoxTel.Location = new System.Drawing.Point(230, 193);
            this.maskedTextBoxTel.Mask = "(999) 000-0000";
            this.maskedTextBoxTel.Name = "maskedTextBoxTel";
            this.maskedTextBoxTel.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBoxTel.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(72, 247);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(142, 24);
            this.label13.TabIndex = 28;
            this.label13.Text = "T.C. Kimlik No :";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.MidnightBlue;
            this.groupBox2.Controls.Add(this.comboBoxCinsiyet);
            this.groupBox2.Controls.Add(this.maskedTextBoxTc);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.maskedTextBoxTel);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.textBoxMüsSoy);
            this.groupBox2.Controls.Add(this.textBoxMüsAdı);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(12, 289);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(524, 341);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MÜŞTERİ BİLGİLERİ";
            // 
            // comboBoxCinsiyet
            // 
            this.comboBoxCinsiyet.FormattingEnabled = true;
            this.comboBoxCinsiyet.Items.AddRange(new object[] {
            "Kadın",
            "Erkek"});
            this.comboBoxCinsiyet.Location = new System.Drawing.Point(230, 142);
            this.comboBoxCinsiyet.Name = "comboBoxCinsiyet";
            this.comboBoxCinsiyet.Size = new System.Drawing.Size(215, 32);
            this.comboBoxCinsiyet.TabIndex = 31;
            // 
            // maskedTextBoxTc
            // 
            this.maskedTextBoxTc.Location = new System.Drawing.Point(230, 244);
            this.maskedTextBoxTc.Mask = "00000000000";
            this.maskedTextBoxTc.Name = "maskedTextBoxTc";
            this.maskedTextBoxTc.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBoxTc.TabIndex = 29;
            this.maskedTextBoxTc.ValidatingType = typeof(int);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label15.Font = new System.Drawing.Font("Cooper Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(134, 304);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(406, 21);
            this.label15.TabIndex = 30;
            this.label15.Text = "*Müşteri ve sefer bilgilerini kontrol ediniz.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(22, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Sefer No :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(156, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 24);
            this.label5.TabIndex = 3;
            this.label5.Text = "Nereden :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(372, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Peron No :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox1.Location = new System.Drawing.Point(135, 158);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(215, 30);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox2.Location = new System.Drawing.Point(490, 177);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(215, 30);
            this.textBox2.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(1, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 24);
            this.label1.TabIndex = 16;
            this.label1.Text = "Sefer Tarihi :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(3, 236);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 24);
            this.label6.TabIndex = 18;
            this.label6.Text = "Sefer Saati :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(356, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 24);
            this.label4.TabIndex = 20;
            this.label4.Text = "Otobüs Adı :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(351, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 24);
            this.label7.TabIndex = 21;
            this.label7.Text = "Sefer Ücreti :";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox3.Location = new System.Drawing.Point(490, 213);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(215, 30);
            this.textBox3.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(472, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 24);
            this.label8.TabIndex = 23;
            this.label8.Text = "Nereye :";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Class",
            "Mini",
            "VIP",
            "Suit"});
            this.comboBox3.Location = new System.Drawing.Point(490, 139);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(215, 32);
            this.comboBox3.TabIndex = 24;
            // 
            // btnDeğiştir
            // 
            this.btnDeğiştir.BackColor = System.Drawing.Color.White;
            this.btnDeğiştir.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeğiştir.ForeColor = System.Drawing.Color.White;
            this.btnDeğiştir.Image = ((System.Drawing.Image)(resources.GetObject("btnDeğiştir.Image")));
            this.btnDeğiştir.Location = new System.Drawing.Point(390, 73);
            this.btnDeğiştir.Name = "btnDeğiştir";
            this.btnDeğiştir.Size = new System.Drawing.Size(66, 42);
            this.btnDeğiştir.TabIndex = 25;
            this.btnDeğiştir.UseVisualStyleBackColor = false;
            this.btnDeğiştir.Click += new System.EventHandler(this.btnDeğiştir_Click);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.maskedTextBox2.Location = new System.Drawing.Point(135, 230);
            this.maskedTextBox2.Mask = "00:00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBox2.TabIndex = 26;
            this.maskedTextBox2.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(135, 195);
            this.maskedTextBox1.Mask = "00/00/0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBox1.TabIndex = 29;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // lblGizli
            // 
            this.lblGizli.AutoSize = true;
            this.lblGizli.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGizli.Location = new System.Drawing.Point(50, 80);
            this.lblGizli.Name = "lblGizli";
            this.lblGizli.Size = new System.Drawing.Size(59, 18);
            this.lblGizli.TabIndex = 16;
            this.lblGizli.Text = "label12";
            this.lblGizli.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.MidnightBlue;
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.lblGizli);
            this.groupBox1.Controls.Add(this.maskedTextBox1);
            this.groupBox1.Controls.Add(this.maskedTextBox2);
            this.groupBox1.Controls.Add(this.btnDeğiştir);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(560, 289);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(711, 341);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SEFER BİLGİLERİ";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox4.Location = new System.Drawing.Point(490, 249);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(215, 30);
            this.textBox4.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(364, 252);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 24);
            this.label12.TabIndex = 30;
            this.label12.Text = "Koltuk No :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.neredenDataGridViewTextBoxColumn,
            this.nereyeDataGridViewTextBoxColumn,
            this.seferNoDataGridViewTextBoxColumn,
            this.seferTarihiDataGridViewTextBoxColumn,
            this.seferSaatiDataGridViewTextBoxColumn,
            this.otobüsAdıDataGridViewTextBoxColumn,
            this.peronNoDataGridViewTextBoxColumn,
            this.seferÜcretiDataGridViewTextBoxColumn,
            this.koltukNoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.seferİslemTblBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(30, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1221, 218);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // neredenDataGridViewTextBoxColumn
            // 
            this.neredenDataGridViewTextBoxColumn.DataPropertyName = "Nereden";
            this.neredenDataGridViewTextBoxColumn.HeaderText = "Nereden";
            this.neredenDataGridViewTextBoxColumn.Name = "neredenDataGridViewTextBoxColumn";
            // 
            // nereyeDataGridViewTextBoxColumn
            // 
            this.nereyeDataGridViewTextBoxColumn.DataPropertyName = "Nereye";
            this.nereyeDataGridViewTextBoxColumn.HeaderText = "Nereye";
            this.nereyeDataGridViewTextBoxColumn.Name = "nereyeDataGridViewTextBoxColumn";
            // 
            // seferNoDataGridViewTextBoxColumn
            // 
            this.seferNoDataGridViewTextBoxColumn.DataPropertyName = "SeferNo";
            this.seferNoDataGridViewTextBoxColumn.HeaderText = "SeferNo";
            this.seferNoDataGridViewTextBoxColumn.Name = "seferNoDataGridViewTextBoxColumn";
            // 
            // seferTarihiDataGridViewTextBoxColumn
            // 
            this.seferTarihiDataGridViewTextBoxColumn.DataPropertyName = "SeferTarihi";
            this.seferTarihiDataGridViewTextBoxColumn.HeaderText = "SeferTarihi";
            this.seferTarihiDataGridViewTextBoxColumn.Name = "seferTarihiDataGridViewTextBoxColumn";
            // 
            // seferSaatiDataGridViewTextBoxColumn
            // 
            this.seferSaatiDataGridViewTextBoxColumn.DataPropertyName = "SeferSaati";
            this.seferSaatiDataGridViewTextBoxColumn.HeaderText = "SeferSaati";
            this.seferSaatiDataGridViewTextBoxColumn.Name = "seferSaatiDataGridViewTextBoxColumn";
            // 
            // otobüsAdıDataGridViewTextBoxColumn
            // 
            this.otobüsAdıDataGridViewTextBoxColumn.DataPropertyName = "OtobüsAdı";
            this.otobüsAdıDataGridViewTextBoxColumn.HeaderText = "OtobüsAdı";
            this.otobüsAdıDataGridViewTextBoxColumn.Name = "otobüsAdıDataGridViewTextBoxColumn";
            // 
            // peronNoDataGridViewTextBoxColumn
            // 
            this.peronNoDataGridViewTextBoxColumn.DataPropertyName = "PeronNo";
            this.peronNoDataGridViewTextBoxColumn.HeaderText = "PeronNo";
            this.peronNoDataGridViewTextBoxColumn.Name = "peronNoDataGridViewTextBoxColumn";
            // 
            // seferÜcretiDataGridViewTextBoxColumn
            // 
            this.seferÜcretiDataGridViewTextBoxColumn.DataPropertyName = "SeferÜcreti";
            this.seferÜcretiDataGridViewTextBoxColumn.HeaderText = "SeferÜcreti";
            this.seferÜcretiDataGridViewTextBoxColumn.Name = "seferÜcretiDataGridViewTextBoxColumn";
            // 
            // koltukNoDataGridViewTextBoxColumn
            // 
            this.koltukNoDataGridViewTextBoxColumn.DataPropertyName = "KoltukNo";
            this.koltukNoDataGridViewTextBoxColumn.HeaderText = "KoltukNo";
            this.koltukNoDataGridViewTextBoxColumn.Name = "koltukNoDataGridViewTextBoxColumn";
            // 
            // seferİslemTblBindingSource1
            // 
            this.seferİslemTblBindingSource1.DataMember = "SeferİslemTbl";
            this.seferİslemTblBindingSource1.DataSource = this.oBS_ProjeDataSet5;
            // 
            // oBS_ProjeDataSet5
            // 
            this.oBS_ProjeDataSet5.DataSetName = "OBS_ProjeDataSet5";
            this.oBS_ProjeDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seferİslemTblTableAdapter1
            // 
            this.seferİslemTblTableAdapter1.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Adana",
            "Ankara",
            "Afyon",
            "Bolu",
            "Bursa",
            "Çanakkale",
            "Denizli",
            "Edirne",
            "Erzincan",
            "Erzurum",
            "Elazığ",
            "Eskişehir",
            "Gaziantep",
            "Hatay",
            "Isparta",
            "İstanbul",
            "İzmir",
            "Kayseri",
            "Konya",
            "Malatya",
            "Muğla",
            "Mardin",
            "Nevşehir",
            "Ordu",
            "Rize",
            "Samsun",
            "Sivas",
            "Trabzon"});
            this.comboBox1.Location = new System.Drawing.Point(160, 79);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(215, 32);
            this.comboBox1.TabIndex = 32;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Adana",
            "Ankara",
            "Afyon",
            "Bolu",
            "Bursa",
            "Çanakkale",
            "Denizli",
            "Edirne",
            "Erzincan",
            "Erzurum",
            "Elazığ",
            "Eskişehir",
            "Gaziantep",
            "Hatay",
            "Isparta",
            "İstanbul",
            "İzmir",
            "Kayseri",
            "Konya",
            "Malatya",
            "Muğla",
            "Mardin",
            "Nevşehir",
            "Ordu",
            "Rize",
            "Samsun",
            "Sivas",
            "Trabzon"});
            this.comboBox2.Location = new System.Drawing.Point(476, 79);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(215, 32);
            this.comboBox2.TabIndex = 33;
            // 
            // Rezervasyonİşlemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 719);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnDevamEt);
            this.Controls.Add(this.btnGeriDön);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Rezervasyonİşlemleri";
            this.Text = "Rezervasyonİşlemleri";
            this.Load += new System.EventHandler(this.Rezervasyonİşlemleri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seferİslemTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seferİslemTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnGeriDön;
        private System.Windows.Forms.Button btnDevamEt;
        private OBS_ProjeDataSet1 oBS_ProjeDataSet1;
        private System.Windows.Forms.BindingSource seferİslemTblBindingSource;
        private OBS_ProjeDataSet1TableAdapters.SeferİslemTblTableAdapter seferİslemTblTableAdapter;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxMüsAdı;
        private System.Windows.Forms.TextBox textBoxMüsSoy;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTc;
        private System.Windows.Forms.ComboBox comboBoxCinsiyet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button btnDeğiştir;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label lblGizli;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView1;
        private OBS_ProjeDataSet5 oBS_ProjeDataSet5;
        private System.Windows.Forms.BindingSource seferİslemTblBindingSource1;
        private OBS_ProjeDataSet5TableAdapters.SeferİslemTblTableAdapter seferİslemTblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn neredenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nereyeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seferNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seferTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seferSaatiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otobüsAdıDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn peronNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seferÜcretiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn koltukNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}