﻿namespace OBS_Proje
{
    partial class SatılanBiletler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SatılanBiletler));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.satılanBiletlerTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oBS_ProjeDataSet2 = new OBS_Proje.OBS_ProjeDataSet2();
            this.btnGeriDön = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGüncelle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnEkle = new System.Windows.Forms.Button();
            this.textBoxKoltukNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSeferNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCinsiyet = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxTc = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.maskedTextBoxTel = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxMüsSoy = new System.Windows.Forms.TextBox();
            this.textBoxMüsAdı = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.satılanBiletlerTblTableAdapter = new OBS_Proje.OBS_ProjeDataSet2TableAdapters.SatılanBiletlerTblTableAdapter();
            this.oBS_ProjeDataSet3 = new OBS_Proje.OBS_ProjeDataSet3();
            this.satılanBiletlerTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.satılanBiletlerTblTableAdapter1 = new OBS_Proje.OBS_ProjeDataSet3TableAdapters.SatılanBiletlerTblTableAdapter();
            this.satılanBiletlerTblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.oBS_ProjeDataSet4 = new OBS_Proje.OBS_ProjeDataSet4();
            this.satılanBiletlerTblTableAdapter2 = new OBS_Proje.OBS_ProjeDataSet4TableAdapters.SatılanBiletlerTblTableAdapter();
            this.oBS_ProjeDataSet6 = new OBS_Proje.OBS_ProjeDataSet6();
            this.satılanBiletlerTblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.satılanBiletlerTblTableAdapter3 = new OBS_Proje.OBS_ProjeDataSet6TableAdapters.SatılanBiletlerTblTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.oBS_ProjeDataSet7 = new OBS_Proje.OBS_ProjeDataSet7();
            this.satılanBiletlerTblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.satılanBiletlerTblTableAdapter4 = new OBS_Proje.OBS_ProjeDataSet7TableAdapters.SatılanBiletlerTblTableAdapter();
            this.müşteriAdıDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.müşteriSoyadıDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cinsiyetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tCKimlikNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seferNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.koltukNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-4, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1310, 778);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // satılanBiletlerTblBindingSource
            // 
            this.satılanBiletlerTblBindingSource.DataMember = "SatılanBiletlerTbl";
            this.satılanBiletlerTblBindingSource.DataSource = this.oBS_ProjeDataSet2;
            // 
            // oBS_ProjeDataSet2
            // 
            this.oBS_ProjeDataSet2.DataSetName = "OBS_ProjeDataSet2";
            this.oBS_ProjeDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnGeriDön
            // 
            this.btnGeriDön.BackColor = System.Drawing.Color.Maroon;
            this.btnGeriDön.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeriDön.ForeColor = System.Drawing.Color.White;
            this.btnGeriDön.Image = ((System.Drawing.Image)(resources.GetObject("btnGeriDön.Image")));
            this.btnGeriDön.Location = new System.Drawing.Point(886, 12);
            this.btnGeriDön.Name = "btnGeriDön";
            this.btnGeriDön.Size = new System.Drawing.Size(294, 43);
            this.btnGeriDön.TabIndex = 15;
            this.btnGeriDön.Text = "Yönetici Sayfasına Dön";
            this.btnGeriDön.UseVisualStyleBackColor = false;
            this.btnGeriDön.Click += new System.EventHandler(this.btnGeriDön_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.MidnightBlue;
            this.groupBox2.Controls.Add(this.btnGüncelle);
            this.groupBox2.Controls.Add(this.btnSil);
            this.groupBox2.Controls.Add(this.btnEkle);
            this.groupBox2.Controls.Add(this.textBoxKoltukNo);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBoxSeferNo);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBoxCinsiyet);
            this.groupBox2.Controls.Add(this.maskedTextBoxTc);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.maskedTextBoxTel);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.textBoxMüsSoy);
            this.groupBox2.Controls.Add(this.textBoxMüsAdı);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(103, 311);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1033, 341);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MÜŞTERİ BİLGİLERİ";
            // 
            // btnGüncelle
            // 
            this.btnGüncelle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnGüncelle.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGüncelle.ForeColor = System.Drawing.Color.White;
            this.btnGüncelle.Location = new System.Drawing.Point(584, 268);
            this.btnGüncelle.Name = "btnGüncelle";
            this.btnGüncelle.Size = new System.Drawing.Size(112, 34);
            this.btnGüncelle.TabIndex = 38;
            this.btnGüncelle.Text = "Güncelle";
            this.btnGüncelle.UseVisualStyleBackColor = false;
            this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSil.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSil.ForeColor = System.Drawing.Color.White;
            this.btnSil.Location = new System.Drawing.Point(702, 268);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(112, 34);
            this.btnSil.TabIndex = 37;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnEkle
            // 
            this.btnEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnEkle.Font = new System.Drawing.Font("Modern No. 20", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEkle.ForeColor = System.Drawing.Color.White;
            this.btnEkle.Location = new System.Drawing.Point(820, 268);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(112, 34);
            this.btnEkle.TabIndex = 36;
            this.btnEkle.Text = "Temizle";
            this.btnEkle.UseVisualStyleBackColor = false;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // textBoxKoltukNo
            // 
            this.textBoxKoltukNo.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxKoltukNo.Location = new System.Drawing.Point(717, 197);
            this.textBoxKoltukNo.Name = "textBoxKoltukNo";
            this.textBoxKoltukNo.Size = new System.Drawing.Size(215, 30);
            this.textBoxKoltukNo.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(591, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 24);
            this.label1.TabIndex = 34;
            this.label1.Text = "Koltuk No :";
            // 
            // textBoxSeferNo
            // 
            this.textBoxSeferNo.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxSeferNo.Location = new System.Drawing.Point(717, 129);
            this.textBoxSeferNo.Name = "textBoxSeferNo";
            this.textBoxSeferNo.Size = new System.Drawing.Size(215, 30);
            this.textBoxSeferNo.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(603, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 32;
            this.label2.Text = "Sefer No :";
            // 
            // comboBoxCinsiyet
            // 
            this.comboBoxCinsiyet.FormattingEnabled = true;
            this.comboBoxCinsiyet.Items.AddRange(new object[] {
            "Kadın",
            "Erkek"});
            this.comboBoxCinsiyet.Location = new System.Drawing.Point(196, 197);
            this.comboBoxCinsiyet.Name = "comboBoxCinsiyet";
            this.comboBoxCinsiyet.Size = new System.Drawing.Size(215, 32);
            this.comboBoxCinsiyet.TabIndex = 31;
            // 
            // maskedTextBoxTc
            // 
            this.maskedTextBoxTc.Location = new System.Drawing.Point(196, 265);
            this.maskedTextBoxTc.Mask = "00000000000";
            this.maskedTextBoxTc.Name = "maskedTextBoxTc";
            this.maskedTextBoxTc.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBoxTc.TabIndex = 29;
            this.maskedTextBoxTc.ValidatingType = typeof(int);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(38, 268);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(142, 24);
            this.label13.TabIndex = 28;
            this.label13.Text = "T.C. Kimlik No :";
            // 
            // maskedTextBoxTel
            // 
            this.maskedTextBoxTel.Location = new System.Drawing.Point(717, 61);
            this.maskedTextBoxTel.Mask = "(999) 000-0000";
            this.maskedTextBoxTel.Name = "maskedTextBoxTel";
            this.maskedTextBoxTel.Size = new System.Drawing.Size(215, 30);
            this.maskedTextBoxTel.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(91, 200);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 24);
            this.label9.TabIndex = 23;
            this.label9.Text = "Cinsiyet :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(585, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 24);
            this.label10.TabIndex = 21;
            this.label10.Text = "Telefon No :";
            // 
            // textBoxMüsSoy
            // 
            this.textBoxMüsSoy.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxMüsSoy.Location = new System.Drawing.Point(196, 129);
            this.textBoxMüsSoy.Name = "textBoxMüsSoy";
            this.textBoxMüsSoy.Size = new System.Drawing.Size(215, 30);
            this.textBoxMüsSoy.TabIndex = 8;
            // 
            // textBoxMüsAdı
            // 
            this.textBoxMüsAdı.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxMüsAdı.Location = new System.Drawing.Point(196, 61);
            this.textBoxMüsAdı.Name = "textBoxMüsAdı";
            this.textBoxMüsAdı.Size = new System.Drawing.Size(215, 30);
            this.textBoxMüsAdı.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(101, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 24);
            this.label14.TabIndex = 4;
            this.label14.Text = "Soyadı :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Corbel", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(131, 64);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "Adı :";
            // 
            // satılanBiletlerTblTableAdapter
            // 
            this.satılanBiletlerTblTableAdapter.ClearBeforeFill = true;
            // 
            // oBS_ProjeDataSet3
            // 
            this.oBS_ProjeDataSet3.DataSetName = "OBS_ProjeDataSet3";
            this.oBS_ProjeDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satılanBiletlerTblBindingSource1
            // 
            this.satılanBiletlerTblBindingSource1.DataMember = "SatılanBiletlerTbl";
            this.satılanBiletlerTblBindingSource1.DataSource = this.oBS_ProjeDataSet3;
            // 
            // satılanBiletlerTblTableAdapter1
            // 
            this.satılanBiletlerTblTableAdapter1.ClearBeforeFill = true;
            // 
            // satılanBiletlerTblBindingSource2
            // 
            this.satılanBiletlerTblBindingSource2.DataMember = "SatılanBiletlerTbl";
            this.satılanBiletlerTblBindingSource2.DataSource = this.oBS_ProjeDataSet4;
            // 
            // oBS_ProjeDataSet4
            // 
            this.oBS_ProjeDataSet4.DataSetName = "OBS_ProjeDataSet4";
            this.oBS_ProjeDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satılanBiletlerTblTableAdapter2
            // 
            this.satılanBiletlerTblTableAdapter2.ClearBeforeFill = true;
            // 
            // oBS_ProjeDataSet6
            // 
            this.oBS_ProjeDataSet6.DataSetName = "OBS_ProjeDataSet6";
            this.oBS_ProjeDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satılanBiletlerTblBindingSource3
            // 
            this.satılanBiletlerTblBindingSource3.DataMember = "SatılanBiletlerTbl";
            this.satılanBiletlerTblBindingSource3.DataSource = this.oBS_ProjeDataSet6;
            // 
            // satılanBiletlerTblTableAdapter3
            // 
            this.satılanBiletlerTblTableAdapter3.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.müşteriAdıDataGridViewTextBoxColumn,
            this.müşteriSoyadıDataGridViewTextBoxColumn,
            this.cinsiyetDataGridViewTextBoxColumn,
            this.telefonNoDataGridViewTextBoxColumn,
            this.tCKimlikNoDataGridViewTextBoxColumn,
            this.seferNoDataGridViewTextBoxColumn,
            this.koltukNoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.satılanBiletlerTblBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(52, 78);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1128, 202);
            this.dataGridView1.TabIndex = 17;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // oBS_ProjeDataSet7
            // 
            this.oBS_ProjeDataSet7.DataSetName = "OBS_ProjeDataSet7";
            this.oBS_ProjeDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // satılanBiletlerTblBindingSource4
            // 
            this.satılanBiletlerTblBindingSource4.DataMember = "SatılanBiletlerTbl";
            this.satılanBiletlerTblBindingSource4.DataSource = this.oBS_ProjeDataSet7;
            // 
            // satılanBiletlerTblTableAdapter4
            // 
            this.satılanBiletlerTblTableAdapter4.ClearBeforeFill = true;
            // 
            // müşteriAdıDataGridViewTextBoxColumn
            // 
            this.müşteriAdıDataGridViewTextBoxColumn.DataPropertyName = "MüşteriAdı";
            this.müşteriAdıDataGridViewTextBoxColumn.HeaderText = "MüşteriAdı";
            this.müşteriAdıDataGridViewTextBoxColumn.Name = "müşteriAdıDataGridViewTextBoxColumn";
            // 
            // müşteriSoyadıDataGridViewTextBoxColumn
            // 
            this.müşteriSoyadıDataGridViewTextBoxColumn.DataPropertyName = "MüşteriSoyadı";
            this.müşteriSoyadıDataGridViewTextBoxColumn.HeaderText = "MüşteriSoyadı";
            this.müşteriSoyadıDataGridViewTextBoxColumn.Name = "müşteriSoyadıDataGridViewTextBoxColumn";
            // 
            // cinsiyetDataGridViewTextBoxColumn
            // 
            this.cinsiyetDataGridViewTextBoxColumn.DataPropertyName = "Cinsiyet";
            this.cinsiyetDataGridViewTextBoxColumn.HeaderText = "Cinsiyet";
            this.cinsiyetDataGridViewTextBoxColumn.Name = "cinsiyetDataGridViewTextBoxColumn";
            // 
            // telefonNoDataGridViewTextBoxColumn
            // 
            this.telefonNoDataGridViewTextBoxColumn.DataPropertyName = "TelefonNo";
            this.telefonNoDataGridViewTextBoxColumn.HeaderText = "TelefonNo";
            this.telefonNoDataGridViewTextBoxColumn.Name = "telefonNoDataGridViewTextBoxColumn";
            // 
            // tCKimlikNoDataGridViewTextBoxColumn
            // 
            this.tCKimlikNoDataGridViewTextBoxColumn.DataPropertyName = "T_C_KimlikNo";
            this.tCKimlikNoDataGridViewTextBoxColumn.HeaderText = "T_C_KimlikNo";
            this.tCKimlikNoDataGridViewTextBoxColumn.Name = "tCKimlikNoDataGridViewTextBoxColumn";
            // 
            // seferNoDataGridViewTextBoxColumn
            // 
            this.seferNoDataGridViewTextBoxColumn.DataPropertyName = "SeferNo";
            this.seferNoDataGridViewTextBoxColumn.HeaderText = "SeferNo";
            this.seferNoDataGridViewTextBoxColumn.Name = "seferNoDataGridViewTextBoxColumn";
            // 
            // koltukNoDataGridViewTextBoxColumn
            // 
            this.koltukNoDataGridViewTextBoxColumn.DataPropertyName = "KoltukNo";
            this.koltukNoDataGridViewTextBoxColumn.HeaderText = "KoltukNo";
            this.koltukNoDataGridViewTextBoxColumn.Name = "koltukNoDataGridViewTextBoxColumn";
            // 
            // SatılanBiletler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1228, 692);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnGeriDön);
            this.Controls.Add(this.pictureBox1);
            this.Name = "SatılanBiletler";
            this.Text = "SatılanBiletler";
            this.Load += new System.EventHandler(this.SatılanBiletler_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oBS_ProjeDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satılanBiletlerTblBindingSource4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnGeriDön;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxCinsiyet;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxMüsSoy;
        private System.Windows.Forms.TextBox textBoxMüsAdı;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxSeferNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKoltukNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGüncelle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnEkle;
        private OBS_ProjeDataSet2 oBS_ProjeDataSet2;
        private System.Windows.Forms.BindingSource satılanBiletlerTblBindingSource;
        private OBS_ProjeDataSet2TableAdapters.SatılanBiletlerTblTableAdapter satılanBiletlerTblTableAdapter;
        private OBS_ProjeDataSet3 oBS_ProjeDataSet3;
        private System.Windows.Forms.BindingSource satılanBiletlerTblBindingSource1;
        private OBS_ProjeDataSet3TableAdapters.SatılanBiletlerTblTableAdapter satılanBiletlerTblTableAdapter1;
        private OBS_ProjeDataSet4 oBS_ProjeDataSet4;
        private System.Windows.Forms.BindingSource satılanBiletlerTblBindingSource2;
        private OBS_ProjeDataSet4TableAdapters.SatılanBiletlerTblTableAdapter satılanBiletlerTblTableAdapter2;
        private OBS_ProjeDataSet6 oBS_ProjeDataSet6;
        private System.Windows.Forms.BindingSource satılanBiletlerTblBindingSource3;
        private OBS_ProjeDataSet6TableAdapters.SatılanBiletlerTblTableAdapter satılanBiletlerTblTableAdapter3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private OBS_ProjeDataSet7 oBS_ProjeDataSet7;
        private System.Windows.Forms.BindingSource satılanBiletlerTblBindingSource4;
        private OBS_ProjeDataSet7TableAdapters.SatılanBiletlerTblTableAdapter satılanBiletlerTblTableAdapter4;
        private System.Windows.Forms.DataGridViewTextBoxColumn müşteriAdıDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn müşteriSoyadıDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cinsiyetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tCKimlikNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seferNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn koltukNoDataGridViewTextBoxColumn;
    }
}